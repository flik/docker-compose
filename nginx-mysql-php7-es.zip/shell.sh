[ "$UID" -eq 0 ] || exec sudo bash "$0" "$@"

docker ps --format '{{.Names}}'

if [ $# -eq 0 ]
  then
    echo -e "\ncontainer name not specified\n"
  else
    echo -e "\ntrying to access to $1 shell\n"
    docker exec -it $1 /bin/bash
fi
