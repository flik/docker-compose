Date date = new Date(doc[date_field].value);
date.format(format);
