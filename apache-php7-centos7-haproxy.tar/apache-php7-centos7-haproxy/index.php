<?php
echo "Server Hotname is:"; echo gethostname();
echo '<hr>';
//phpinfo();

?>

