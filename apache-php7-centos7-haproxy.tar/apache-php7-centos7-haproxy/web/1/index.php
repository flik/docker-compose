<?php
echo "Server 1 Hostname is:"; echo gethostname();
?>

