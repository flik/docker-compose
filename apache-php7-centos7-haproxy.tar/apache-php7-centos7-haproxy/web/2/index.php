<?php
echo "Server  2 Hostname is:"; echo gethostname();
?>

